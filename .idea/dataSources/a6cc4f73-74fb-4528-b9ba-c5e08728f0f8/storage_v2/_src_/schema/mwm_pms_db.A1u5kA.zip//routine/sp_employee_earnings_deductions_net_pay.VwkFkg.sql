create
    definer = root@localhost procedure sp_employee_earnings_deductions_net_pay(IN employee_id bigint unsigned)
BEGIN
    SELECT
        s.total_gross_earnings,
        s.total_deductions,
        s.net_salary
    FROM salaries s
    WHERE s.employee_id = employee_id
    ORDER BY s.month DESC
    LIMIT 1;
END;

