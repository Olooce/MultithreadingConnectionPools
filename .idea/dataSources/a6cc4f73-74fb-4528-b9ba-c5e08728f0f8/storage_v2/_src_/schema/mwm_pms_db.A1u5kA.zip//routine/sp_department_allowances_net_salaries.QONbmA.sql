create
    definer = root@localhost procedure sp_department_allowances_net_salaries(IN department_id bigint unsigned, IN _month date)
BEGIN
    SELECT
        e.name,
        SUM(a.total_allowance) AS total_allowances,
        s.net_salary
    FROM employees e
             JOIN salaries s ON e.employee_id = s.employee_id
             JOIN allowances a ON s.salary_id = a.employee_id
    WHERE e.department_id = department_id
      AND s.month = _month
    GROUP BY e.name, s.net_salary;
END;

