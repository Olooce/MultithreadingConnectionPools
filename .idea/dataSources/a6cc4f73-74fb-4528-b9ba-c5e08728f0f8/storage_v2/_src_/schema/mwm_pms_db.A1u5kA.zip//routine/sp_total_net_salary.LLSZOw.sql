create
    definer = root@localhost procedure sp_total_net_salary(IN _month date)
BEGIN
    SELECT SUM(s.net_salary) AS total_net_salary
    FROM salaries s
    WHERE month = _month;
END;

