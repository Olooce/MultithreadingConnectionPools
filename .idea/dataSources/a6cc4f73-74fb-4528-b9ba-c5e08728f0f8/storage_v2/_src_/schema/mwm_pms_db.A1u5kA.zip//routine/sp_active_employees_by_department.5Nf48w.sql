create
    definer = root@localhost procedure sp_active_employees_by_department(IN department_id bigint unsigned)
BEGIN
    SELECT COUNT(*) AS total_active_employees
    FROM employees e
    WHERE e.department_id = department_id AND e.status = 'ACTIVE';
END;

