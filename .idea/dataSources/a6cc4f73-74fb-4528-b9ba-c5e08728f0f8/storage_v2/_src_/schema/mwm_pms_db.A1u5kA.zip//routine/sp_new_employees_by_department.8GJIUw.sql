create
    definer = root@localhost procedure sp_new_employees_by_department()
BEGIN
    SELECT d.department_name, e.name, e.employment_date
    FROM employees e
             JOIN departments d ON e.department_id = d.department_id
    WHERE e.status = 'NEW'
    GROUP BY d.department_name, e.name, e.employment_date;
END;

