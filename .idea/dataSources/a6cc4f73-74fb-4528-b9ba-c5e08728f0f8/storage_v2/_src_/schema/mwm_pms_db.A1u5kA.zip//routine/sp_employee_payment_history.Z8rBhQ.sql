create
    definer = root@localhost procedure sp_employee_payment_history(IN employee_id bigint unsigned)
BEGIN
    SELECT
        s.month,
        s.total_gross_earnings,
        s.total_taxes,
        s.net_salary
    FROM salaries s
    WHERE s.employee_id = employee_id
    ORDER BY s.month DESC;
END;

